<template>
  <div class="commentContent" >
  <!-- 添加左右滑动事件 -->
   <div id="productList">
    <div class="header-nav" id="productList">
         <ul class="comment-tap">
          <li v-for="(item,index) in commentnavItems" @click="tapComment(index)" v-bind:class="[tapNum==index ? tapactive : '']">
            <a href="javascript:void(0)" :name="'WapYoupin_pjxq_tab_'+buryingpoint[index]">
              <span>{{item.countType}}</span>
              <em>{{item.countValue}}</em>
            </a>
          </li>
      </ul>
      <span class="comment-tapborder" v-bind:style="{left:leftpx+'px'}"></span>
    </div>
    <!-- 二级筛选分类 -->
    <div class="comment-subtap" v-if="tapNum==0">
          <a :name="'WapYoupin_pjxq_biaoqian_'+(index+1)" v-for="(item,index) in subitems" @click="subtapComment(index,item.tagName)" v-bind:class="[subtapIndex==index ? subtapactive : '']">{{item.tagName}}({{item.tagTimes}})</a>
      </div>
    <!-- 评论列表 -->
  <transition name="fade">
    <div class="comment-list" v-show="commNodata">
        <div class="commlist-header">
            <span class="coment-totalnum">评价({{totalNum}})</span>
            <span class="comment-rate">好评率&nbsp;<em>{{satisfyRate}}%</em></span>
        </div>
        <ul>
             <li class="comment-item" v-for="(item,index) in commentContentitem" v-bind:key="index">
                 <div class="ge-comtital">
                   <!-- 用户信息 -->
                    <div class="user-name">
                         <div class="user-tital">
                             <span>{{item.custNick}}</span><i class="user-grade" :class="'grade'+item.custLevel"></i>
                        </div>
                        <p class="ge-time">{{item.commTime}}</p>
                    </div>
                       <!-- 星等级 -->
                    <div class="star-grade" :class="'star-grade'+item.commStar">
                        <i></i>
                        <i></i>
                        <i></i>
                        <i></i>
                        <i></i>
                    </div>
                    <p class="commentinit">{{item.commContent}}</p>
                </div>
            <!-- 图片区 -->
            <div class="group-img">
                <img :src="'//image.suning.cn/uimg/ZR/share_order/'+itemid+'_400x400.jpg?format=200h_200w_80Q'+toWepb" alt="" v-for="(itemid,index) in item.commPic" @click="getBgview(index,item)"/>
            </div>
            <p class="add-to-comment" v-if="item.commAdded!=undefined&&item.commAdded.length>0">购买{{item.commAddedTime}}后追评</p>
            <div class="ge-comcen">
                <p v-if="item.commAdded!=undefined&&item.commAdded.length>0">{{item.commAdded}}</p>
                <div class="production-info">
                    <p>{{item.shopName}}</p>
                    <p><span>{{item.cmmdtyModel}} {{item.commParam}}</span></p>
                </div>
            </div>
            <div class="addcomment-content" v-if="item.shopReply!=''&&item.shopName!=undefined&&item.shopReply!=undefined">
                <h4>{{item.shopName}}</h4>
                <p><em></em>{{item.shopReply}}</p>
            </div>
        </li>
    </ul>
         
     
    </div>
    </transition>
    <!-- </v-touch> -->
      <transition name="fade">

    <div class="nocomm-data" v-if="!commNodata">
        暂无评论
    </div>
    </transition>
   </div>
    <!-- 点击看大图 -->
      <transition name="fade" v-on:before-enter="beforeEnter" v-on:after-leave="afterLeave">
      <div class="viewBgimg" v-if="viewType">
     <!-- 点击看大图组件 -->
        <div class="previewimage-bg"></div>
        <section class="previewimage">
            <div class="viewbgimg-header"><a href="javascript:void(0)" class="goBack-prev" @click="closeLay"></a>
               <span class="swiper-pagination swiper-pagination-fraction"></span>
            </div>
            <div class="previewimage-con swiper-container" @touchmove.prevent>
                <ul class="swiper-wrapper">
                    <li class="swiper-slide" v-for="(itemid,index) in swiperArr"><img @click="closeLay" class="swiper-lazy" :data-src="'//image.suning.cn/uimg/ZR/share_order/'+itemid+'_400x400.jpg?format='+toWepb"/></li>
                </ul>
            </div>
            <div class="viewbgimg-footer" @touchstart="touchFun($event)">
                    <div class="user-tital">
                         <span>{{bigCustname}}</span>
                    </div>
                   <!-- 星等级 -->
                    <div class="star-grade" :class="'star-grade'+bigCustleave">
                        <i></i>
                        <i></i>
                        <i></i>
                        <i></i>
                        <i></i>
                    </div>
                    <div class="ge-comcen">
                      <p>{{imgcommtext}}</p>
                  </div>
            </div>
        </section>
    </div>
    </transition>
  </div>

</template>

<script>
import { swiper, swiperSlide } from 'vue-awesome-swiper'
import "dropload"
export default {
  name: 'commentContent',
  props: ['isApp'],
  data () {
    return {
      msg: '二手评论页内容',
      commentnavItems:[],//评论大的分类内容
      commentContentitem:[],//评论内容的数组
      subitems:[],//评论的二级分类内容
      leftpx:0,//下面的红色border距离右边的距离;
      tapactive:"tapactive",//实现tap的class
      subtapactive:"subtapactive",
      viewType:false,//查看大图是否显示
      tapNum:0,//头部tab切换的时候使用的index;
      swiperArr:[],//大图图片
      bigCustname:"",//大图下评论的名称
      bigCustleave:1,//大图中评论者等级;
      satisfyRate:"",//好评率
      totalNum:"",//评价总条数
      myswiper:'',
      commqueryType:1,//大分类;
      commqueryParam:1,//二级分类
      pageNo:1,//第几页
      imgcommtext:"",//显示大图时候的评论
      addCommentText:false,//是否显示追评
      commNodata:true,
      subtapIndex:-1,//二级标签的显示
      buryingpoint:["all","youtu","haoping","zhongping","chaping","zhuiping"],//埋点
      protocol:"",//协议头
      ajaxUrl:"",//域名
      pageSize:200,
      commNum:[],//评论的数的数组存放;
      toWepb:""
    }
  },
  created:function(){
    var subtagName;
     this.protocol = (("https:" == document.location.protocol) ? "https:" : "http:");
     var root="${wapServerRoot}"
     this.ajaxUrl=root;
     if(this.ajaxUrl!="/list"){
      this.ajaxUrl="";
     };
     getIsSupport()?this.toWepb=".webp":this.toWepb="";
     /*封装touch事件*/

  },
  mounted(){
    var that=this;//在ajax中this指向改变
    var _scrollover;
    var arrType=["全部","带图","好评","中评","差评","追评"]
      $.ajax({
         url: that.ajaxUrl+'/service/getSopCommCount.htm',
         type: 'POST', 
         datatype:"json",
         data: JSON.stringify({versionNo:"1.0",reqBody:""}),
       })
       .done(function(res) {
          res=$.parseJSON(res);
        if (res.code=="0000") {
          var dataArr=$.parseJSON(res.rspBody);
          for (var i = 0; i < dataArr.commCountList.length; i++) {
            dataArr.commCountList[i].countType=arrType[dataArr.commCountList[i].countType-1];
            that.commNum[i]=dataArr.commCountList[i].countValue
          };
          that.commentnavItems=dataArr.commCountList;
          that.totalNum=dataArr.commCountList[0].countValue;
          that.subitems=dataArr.commTagCountList.slice(0,6);
          var data={
            reqBody:JSON.stringify({
              queryType:1,
              queryParam:1,
              pageNo:1,
              pageSize:that.pageSize
            }),
            versionNo:"1.0"
          };
          //调用评论结果页
          that.getComment(data);
        }else{
          var commentnavItems=[],subitems=[];
           for (var i = 0; i < 6; i++) {
           var obj={
                countType:arrType[i],
                countValue:0
            };
            commentnavItems[i]=obj;
          };
          that.commentnavItems=commentnavItems
          that.subitems=[];
          that.commNodata=false;
          console.log("数据请求错误")
        }
       })
       .fail(function() {
          var commentnavItems=[],subitems=[];
           for (var i = 0; i < 6; i++) {
           var obj={
                countType:arrType[i],
                countValue:0
            };
            commentnavItems[i]=obj;
          };
          that.commentnavItems=commentnavItems
          that.subitems=[];
          that.commNodata=false;
         console.log("error");
       })
       .always(function() {
       });
      // 监控滚动条
      
       // 滚动条事件
      $(window).scroll(function(){
        clearTimeout(_scrollover);
        _scrollover = setTimeout(function() {
          var headerNavh=$(".header-nav").height();
          if (that.isApp){//去除顶部,添加定位
           var headerH=$(".header").height();
            if(window.pageYOffset>=headerH){
                $(".header-nav").next().css("margin-top",headerNavh/1+10);
                $(".header-nav").addClass('header-navfixed');
              }else{
                $(".header-nav").removeClass('header-navfixed');
               $(".header-nav").next().css("margin-top","0.2rem")
              }
          }else{
          if(window.pageYOffset>=5){
                $(".header-nav").next().css("margin-top",headerNavh/1+10);
                $(".header-nav").addClass('header-navfixed');
              }else{
                $(".header-nav").removeClass('header-navfixed');
               $(".header-nav").next().css("margin-top","0.2rem")
              }
          }
        },10);
      });
      // touch事件
        (function(){
          var _initX = 0,_initY=0, _finishX = 0,_finishY=0,_startX = 0,_startY = 0;
          document.getElementById("productList").addEventListener("touchstart", function (e) {
              _startX = event.touches[0].clientX;
              _startY = event.touches[0].clientY;
              _initX = _startX;
              _initY=_startY;
          }, true);
          document.getElementById("productList").addEventListener("touchmove", function (e) {
              var touches = event.touches;
              var _endX = event.touches[0].clientX;
              var _endY = event.touches[0].clientY;
              _finishX=0;
              if (Math.abs(_endY - _startY) > Math.abs(_endX - _startX)) {
                  return;//上下滑动无效
              }
              event.preventDefault(); //取消默认操作
              _finishX = _endX;
              _finishY=_endY;
          }, true);
          document.getElementById("productList").addEventListener("touchend", function (e) {
              if (_finishX == 0) return;
              if(Math.abs(_finishX - _startX)<30||Math.abs(_finishY - _startY)>60) return;

              if(_initX<_finishX){
                 var a=that.tapNum;
                  a<=0?a=0:a-=1;
                  that.tapComment(a);
              }else{
                 var a=that.tapNum;
                a>=5?a=5:a+=1;
                that.tapComment(a);
              }
              _initX = 0;
              _finishX = 0;
          }, true);
        })();
    },
  methods:{
    
    tapComment(index){//点击每个LI的时候的函数
        var num=$(".comment-tap li").width();
        var that=this;
        var headerNavh=$(".header-nav").height();
        that.totalNum=that.commNum[index];
        this.leftpx=index*num;
        if (index==0) {
          $(".header-nav").removeClass('header-navfixed');
          $(".comment-list").css("margin-top","0.2rem");
          $(".comment-subtap").css("margin-top","0.2rem");
        };
        that.pageSize=that.getPagenum(index);
        if (index==0&&that.subtapIndex!=-1) {
              that.commqueryType=2;
                $(".dropload-down").remove();
                  var data={
                  reqBody:JSON.stringify({
                    queryType:that.commqueryType,
                    queryParam:that.subtagName,
                    pageNo:1,
                    pageSize:200
                  }),
                  versionNo:"1.0"
                };
                //调用评论数据
                that.getComment(data);
                that.tapNum=index;
        }else if (this.tapNum!=index) {
               that.commqueryType=1;
               that.commqueryParam=index/1+1;
               $(".dropload-down").remove();
               $(window).scrollTop(0);
                  var data={
                  reqBody:JSON.stringify({
                    queryType:that.commqueryType,
                    queryParam:that.commqueryParam,
                    pageNo:1,
                    pageSize:that.pageSize
                  }),
                  versionNo:"1.0"
                };
                //调用评论数据
                 that.getComment(data);
                that.tapNum=index;
        }
    },   
    subtapComment(index,tagName){
        var that=this;
         if (this.subtapIndex!=index) {
               that.commqueryType=2;
               that.commqueryParam=tagName;
               that.subtagName=tagName;
                $(".dropload-down").remove();
                  var data={
                  reqBody:JSON.stringify({
                    queryType:that.commqueryType,
                    queryParam:that.commqueryParam,
                    pageNo:1,
                    pageSize:200
                  }),
                  versionNo:"1.0"
                };
                //调用评论数据
                that.getComment(data);
               that.subtapIndex=index;
        }else{
               that.commqueryType=1;
               that.subtapIndex=-1;
                $(".dropload-down").remove();
                  var data={
                  reqBody:JSON.stringify({
                    queryType:1,
                    queryParam:1,
                    pageNo:1,
                    pageSize:200
                  }),
                  versionNo:"1.0"
                };
                //调用评论数据
                that.getComment(data);
        }
    },
    closeLay(){//关闭弹窗
        window.history.go(-1);
        this.viewType=false;
    },
    getBgview(index,item){//点击查看大图
        // 初始化swiper
        window.location.hash = "#img";
        var that=this;
        this.viewType=true;
        this.swiperArr=[];
        this.swiperArr=item.commPic;
        this.imgcommtext=item.commContent;
        this.bigCustname=item.custNick,//大图下评论的名称
        this.bigCustleave=item.commStar,//大图中评论者等级;
      setTimeout(function(){
        that.myswiper = new Swiper('.previewimage-con', {
            slidesPerView: 'auto',
            lazyLoading: true,
            pagination: '.swiper-pagination',
            paginationType: 'fraction',
            lazyLoading : true,
            touchMoveStopPropagation:true
        });
        var bannerLen = $(".previewimage-con ul").find("li").length;
        $(".previewimage-con ul").css({
            "width": (bannerLen * 15) + "rem"
        });
         that.myswiper.slideTo(index,1);
        },20)
    },
    touchFun(event){
      event.stopPropagation();
    },
    beforeEnter(){
      $(".header-nav").css('z-index','0');
    },
    afterLeave(){
      $(".header-nav").css('z-index','20');
    },
    getComment(data){
      var that=this;
      $.ajax({
         url: that.ajaxUrl+'/service/getSopCommList.htm',
         type: 'POST',
         datatype:"json",
         data: JSON.stringify(data),
       })
       .done(function(res) {
        res=$.parseJSON(res);

        if (res.code=="0000") {
          that.commentContentitem=[];
          var datares=$.parseJSON(res.rspBody);
          that.satisfyRate=datares.satisfyRate;
          var arr=datares.commList;
            $("body").dropload({
              dataArr:arr,
              threshold :10,// 提前加载距离
              parentClass:"comment-list",
              loadDownFn:function(arr){
                var commTime,commAddedTime;
                for (var i = 0; i < arr.length; i++) {
                  if (arr[i].commAddedTime!=undefined) {
                      commTime=Date.parse(arr[i].commTime.replace(/-/g, "/"));
                      commAddedTime=Date.parse(arr[i].commAddedTime.replace(/-/g, "/"));
                      arr[i].commAddedTime=that.getValtime(commAddedTime-commTime);
                  };
                  arr[i].commTime=arr[i].commTime.substring(0,11);
                  if(arr[i].commPic.length!=0&&arr[i].commPic!=undefined){
                   arr[i].commPic=arr[i].commPic.split(",",9);
                  }else{
                    arr[i].commPic=[];
                  }
                  that.commentContentitem.push(arr[i]);
                };
                that.commNodata=true;
                
              }
          })
        }else{
          that.commNodata=false;
          console.log("数据请求错误");
          var arr=[];
            $("body").dropload({
              dataArr:arr,
              threshold :10,// 提前加载距离
              parentClass:"comment-list",
              loadDownFn:function(arr){
                
              }
          })
        }
       })
       .fail(function() {
            that.commNodata=false;
            console.log("error");
            var arr=[];
            $("body").dropload({
              dataArr:arr,
              threshold :10,// 提前加载距离
              parentClass:"comment-list",
              loadDownFn:function(arr){
                
              }
          })
       })
       .always(function() {
       });
    },
    /*时间转化函数*/
    getValtime(n){
      var a;
      var n=n/1000;
      switch(true){
        case 0<n&&n<60:
        a=parseInt(n)+"秒";break;
        case 60<=n&&n<3600:
        a=parseInt(n/60)+"分钟";break;
        case 3600<=n&&n<86400:
        a=parseInt(n/3600)+"小时";break;
         case n>=86400:
        a=parseInt(n/86400)+"天";break;
          default :
          a=0;break;
      };
      return a;
    },
    getPagenum(n){
      var a;
      switch(n){
        case n=0:
         a=200;break;
       case n=4:
         a=50;break;
          default :
          a=100;break;
      };
      return a;
    }
  }
  
}
</script>


