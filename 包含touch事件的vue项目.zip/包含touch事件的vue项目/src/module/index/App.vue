<template>
    <div id="app">
        <h2 class="wrap">idjfldsjflsdlfjlsjfl</h2>
        <!--<img src="./images/bg.png" />-->
        <hr />
        <div class="bg"></div>
        <hr />
        <div class="icon"></div>
    </div>
</template>

<style lang="scss">
</style>

<script>

    export default {
        name: 'app',
        data(){
            return{
                noApp:"true"
            }
        },
        components:{
        },
        mounted(){

        },
        created:function(){

        },
        methods:{

        }
    }
</script>
