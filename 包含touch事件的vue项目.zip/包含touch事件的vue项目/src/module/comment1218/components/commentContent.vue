<template>
  <div class="commentContent" >
    <!-- 二级筛选分类 -->
    <div class="good-commhader">
      <p class="commAll">共有 <span>{{totalNum}}</span> 条评价</p>
      <div class="comm-rot">
        <span>好评率 </span><span class="comm-rotnum">{{satisfyRate}}%</span>
      </div>
    </div>
  <div class="comment-subtap-wrap">
      <div class="comment-subtap" v-if="tapNum==0">
          <a :name="'WapYoupin_pjxq_biaoqian_'+(index+1)" v-for="(item,index) in subitems" @click="subtapComment(index,item.tagName)" v-bind:class="[subtapIndex==index ? subtapactive : '']">{{item.tagName}}<span v-if="index!=0">({{item.tagTimes}})</span></a>
      </div>
  </div>
    <!-- 评论列表 -->
  <transition name="fade">
    <div class="comment-list" v-show="commNodata">
        <ul class="comment-list-ul">
             <li class="comment-item" v-for="(item,index) in commentContentitem" v-bind:key="index">
                 <div class="ge-comtital">
                   <!-- 用户信息 -->
                    <div class="user-name">
                         <div class="user-tital">
                             <span>{{item.custNick}}</span><i class="user-grade" :class="'grade'+item.custLevel"></i>
                        </div>
                        <p class="ge-time">{{item.commTime}}</p>
                    </div>
                       <!-- 星等级 -->
                    <div class="star-grade" :class="'star-grade'+item.commStar">
                        <i></i>
                        <i></i>
                        <i></i>
                        <i></i>
                        <i></i>
                    </div>
                    <p class="commentinit">{{item.commContent}}</p>
                </div>
            <!-- 图片区 -->
            <div class="group-img">
                <img :src="'//image.suning.cn/uimg/ZR/share_order/'+itemid+'_400x400.jpg?format=200h_200w_80Q'+toWepb" alt="" v-for="(itemid,index) in item.commPic" @click="getBgview(index,item)"/>
            </div>
            <div class="ge-comcen">
                <div class="production-info">
                    <p>{{item.shopName}}</p>
                    <p><span>{{item.cmmdtyModel}} {{item.commParam}}</span></p>
                </div>
            </div>
            <div class="addcomment-content" v-if="item.shopReply!=''&&item.shopName!=undefined&&item.shopReply!=undefined">
                <h4>{{item.shopName}}回复:</h4>
                <p><em></em>{{item.shopReply}}</p>
            </div>
        </li>
    </ul>
         
     
    </div>
    </transition>
    <!-- </v-touch> -->
    <transition name="fade">

    <div class="nocomm-data" v-if="!commNodata">
        暂无评论
    </div>
    </transition>
    <!-- 点击看大图 -->
      <transition name="fade">
      <div class="viewBgimg" v-if="viewType">
     <!-- 点击看大图组件 -->
        <div class="previewimage-bg" @touchmove.prevent></div>
        <section class="previewimage">
            <div class="viewbgimg-header"  @touchmove.prevent><a href="javascript:void(0)" @touchmove.prevent class="goBack-prev" @click="closeLay"></a>
               <span class="swiper-pagination swiper-pagination-fraction"></span>
            </div>
            <div class="previewimage-con swiper-container">
                <ul class="swiper-wrapper">
                    <li class="swiper-slide" v-for="(itemid,index) in swiperArr"><img @click="closeLay" class="swiper-lazy" :data-src="'//image.suning.cn/uimg/ZR/share_order/'+itemid+'_400x400.jpg?format='+toWepb"/></li>
                </ul>
            </div>
            <div class="viewbgimg-footer" v-if="addCommmodule"  @touchstart="touchFun($event)">
                    <div class="user-tital">
                         <span>{{bigCustname}}</span>
                    </div>
                   <!-- 星等级 -->
                    <div class="star-grade" :class="'star-grade'+bigCustleave">
                        <i></i>
                        <i></i>
                        <i></i>
                        <i></i>
                        <i></i>
                    </div>
                    <div class="ge-comcen">
                      <p>{{imgcommtext}}</p>
                  </div>
            </div>
        </section>
    </div>
    </transition>
  </div>

</template>

<script>
import { swiper, swiperSlide } from 'vue-awesome-swiper'
import "dropload"
export default {
  name: 'commentContent',
  props: ['isApp'],
  data () {
    return {
      msg: '二手评论页内容',
      commentContentitem:[],//评论内容的数组
      subitems:[{tagName:"全部",tagTimes:''},{tagName:"带图",tagTimes:''}],//评论的二级分类内容
      leftpx:0,//下面的红色border距离右边的距离;
      tapactive:"tapactive",//实现tap的class
      subtapactive:"subtapactive",
      viewType:false,//查看大图是否显示
      tapNum:0,//头部tab切换的时候使用的index;
      swiperArr:[],//大图图片
      bigCustname:"",//大图下评论的名称
      bigCustleave:1,//大图中评论者等级;
      satisfyRate:"",//好评率
      totalNum:"",//评价总条数
      myswiper:'',
      commqueryParam:1,//二级分类
      pageNo:1,//第几页
      imgcommtext:"",//显示大图时候的评论
      addCommentText:false,//是否显示追评
      commNodata:true,
      subtapIndex:0,//二级标签的显示
      buryingpoint:["all","youtu","haoping","zhongping","chaping","zhuiping"],//埋点
      protocol:"",//协议头
      ajaxUrl:"",//域名
      pageSize:200,
      commNum:[],//评论的数的数组存放;
      toWepb:"",
      windowTop:0,
      addCommmodule:true,
      commonHight:''
    }
  },  
  created:function(){
    var subtagName;
    var that=this;
     this.protocol = (("https:" == document.location.protocol) ? "https:" : "http:");
     var root="${wapServerRoot}"
     this.ajaxUrl=root;
     if(this.ajaxUrl!="/list"){
      this.ajaxUrl="";
     };
     getIsSupport()?this.toWepb=".webp":this.toWepb="";
     /*封装touch事件*/
     if(device.isApp){
        that.addCommmodule=true;
        that.commonHight=0;
     }else{
        that.addCommmodule=false;
        that.commonHight=100;
     }
  },
  mounted(){
    var that=this;//在ajax中this指向改变
    var _scrollover;
      $.ajax({
         url: that.ajaxUrl+'/service/getSopCommCount.htm',
         type: 'POST', 
         datatype:"json",
         data: JSON.stringify({
          versionNo:"1.0",
          reqBody:''
         }),
       })
       .done(function(res) {
          res=$.parseJSON(res);
        if (res.code=="0000") {
          var dataArr=$.parseJSON(res.rspBody);
          for (var i = 0; i < dataArr.commCountList.length; i++) {
            that.commNum[i]=dataArr.commCountList[i].countValue
          };
          that.totalNum=dataArr.commCountList[0].countValue;

           that.subitems[0].tagTimes=dataArr.commCountList[0].countValue;
          that.subitems[1].tagTimes=dataArr.commCountList[1].countValue;
          var arr=dataArr.commTagCountList.slice(0,6);
          for (var i = 0; i < arr.length; i++) {
            that.subitems.push(arr[i]);
          };
          var data={
            reqBody:JSON.stringify({
              queryType:1,
              queryParam:1,
              pageNo:1,
              pageSize:that.pageSize
            }),
            versionNo:"1.0"
          };
          //调用评论结果页
          that.getComment(data);
        }else{
          
          console.log("数据请求错误")
        }
       })
       .fail(function() {
      
         console.log("error");
       })
       .always(function() {
       });
    },
  methods:{
    subtapComment(index,tagName){
        var that=this;
          if(index<=1&&this.subtapIndex!=index){
             $(".dropload-down").remove();
                  var data={
                  reqBody:JSON.stringify({
                    queryType:1,
                    queryParam:index+1,
                    pageNo:1,
                    pageSize:200
                  }),
                  versionNo:"1.0"
                };
                //调用评论数据
                that.getComment(data);
               that.subtapIndex=index;
          }
         if (this.subtapIndex!=index) {
               that.commqueryParam=tagName;
               that.subtagName=tagName;
                $(".dropload-down").remove();
                  var data={
                  reqBody:JSON.stringify({
                    queryType:2,
                    queryParam:that.commqueryParam,
                    pageNo:1,
                    pageSize:200
                  }),
                  versionNo:"1.0"
                };
                //调用评论数据
                that.getComment(data);
               that.subtapIndex=index;
        }
    },
    closeLay(){//关闭弹窗
       var that=this;
        window.history.go(-1);
        $('body').off('touchmove');//解除阻止
        this.viewType=false;
    },
    getBgview(index,item){//点击查看大图
        // 初始化swiper
        window.location.hash = "#img";
        var that=this;
        this.viewType=true;
        this.swiperArr=[];
        this.swiperArr=item.commPic;
        this.imgcommtext=item.commContent;
        this.bigCustname=item.custNick,//大图下评论的名称
        this.bigCustleave=item.commStar,//大图中评论者等级;
      setTimeout(function(){
        that.myswiper = new Swiper('.previewimage-con', {
            slidesPerView: 'auto',
            lazyLoading: true,
            pagination: '.swiper-pagination',
            paginationType: 'fraction',
            lazyLoading : true,
            touchMoveStopPropagation:true
        });
        var prevHeight = $(window).height() - $(".viewbgimg-header").height()-$(".viewbgimg-footer").height()-40-that.commonHight;
        var bannerLen = $(".previewimage-con ul").find("li").length;
        $(".previewimage-con ul").css({
            "width": (bannerLen * 15) + "rem",
            "height":prevHeight+'px'
        });
        // $("body").addClass('fixedstyel')
         that.myswiper.slideTo(index,1);
        $('body').on('touchmove', function (e) {//阻止用户滚动页面
            e.preventDefault();
        });
        },20)
    },
    touchFun(event){
      event.stopPropagation();
    },
    getComment(data){
      var that=this;
      $.ajax({
         url: that.ajaxUrl+'/service/getSopCommList.htm',
         type: 'POST',
         datatype:"json",
         data: JSON.stringify(data),
       })
       .done(function(res) {
        res=$.parseJSON(res);
        if (res.code=="0000") {
          that.commentContentitem=[];
          var datares=$.parseJSON(res.rspBody);
          that.satisfyRate=datares.satisfyRate;
          var arr=datares.commList;
            $("body").dropload({
              dataArr:arr,
              threshold :100,// 提前加载距离
              parentClass:"comment-list",
              loadDownFn:function(arr){
                var commTime,commAddedTime;
                for (var i = 0; i < arr.length; i++) {
                  if (arr[i].commAddedTime!=undefined) {
                      commTime=Date.parse(arr[i].commTime.replace(/-/g, "/"));
                      commAddedTime=Date.parse(arr[i].commAddedTime.replace(/-/g, "/"));
                      arr[i].commAddedTime=that.getValtime(commAddedTime-commTime);
                  };
                  arr[i].commTime=arr[i].commTime.substring(0,11);
                  if(arr[i].commPic.length!=0&&arr[i].commPic!=undefined){
                   arr[i].commPic=arr[i].commPic.split(",",9);
                  }else{
                    arr[i].commPic=[];
                  }
                  that.commentContentitem.push(arr[i]);
                };
                that.commNodata=true;
                
              }
          })
        }else{
          that.commNodata=false;
          console.log("数据请求错误");
          var arr=[];
            $("body").dropload({
              dataArr:arr,
              threshold :10,// 提前加载距离
              parentClass:"comment-list",
              loadDownFn:function(arr){
                
              }
          })
        }
       })
       .fail(function() {
            that.commNodata=false;
            console.log("error");
            var arr=[];
            $("body").dropload({
              dataArr:arr,
              threshold :10,// 提前加载距离
              parentClass:"comment-list",
              loadDownFn:function(arr){
                
              }
          })
       })
       .always(function() {
       });
    },
    /*时间转化函数*/
    getValtime(n){
      var a;
      var n=n/1000;
      switch(true){
        case 0<n&&n<60:
        a=parseInt(n)+"秒";break;
        case 60<=n&&n<3600:
        a=parseInt(n/60)+"分钟";break;
        case 3600<=n&&n<86400:
        a=parseInt(n/3600)+"小时";break;
         case n>=86400:
        a=parseInt(n/86400)+"天";break;
          default :
          a=0;break;
      };
      return a;
    },
    getPagenum(n){
      var a;
      switch(n){
        case n=0:
         a=200;break;
       case n=4:
         a=50;break;
          default :
          a=100;break;
      };
      return a;
    }
  }
  
}
</script>


