<template>
  <div id="app">
    <header-content :isApp = "noApp"></header-content>
    <comment-content :isApp = "noApp"></comment-content>
      </div>
</template>

<script>
import headerContent from "../../components/header.vue"
import commentContent from './components/commentContent.vue'

//二手优品首页
  window.callIndex = function () {
    window.location.href= '//2.m.suning.com/wap/index.htm';
  }
  //类目/搜索
  window.callSearch = function () {
    window.location.href='//s2.suning.com/wap/searchall.htm';
  }
  //易回收
  window.callShp = function () {
    window.location.href= '//hx.suning.com/wap/index.do';
  }
  //我的消息
  window.callRecycle = function () {
    window.location.href= '//2.m.suning.com/wap/message/home.do';
  }
  //我的回收
  window.mtCenter = function () {
    window.location.href= '//2.m.suning.com/wap/mycenter.do';
  }
export default {
  name: 'app',
  data(){
    return{
       noApp:"true"
    }
  },
  components:{
    headerContent,
    commentContent
  },
  mounted(){
     
  },
  created:function(){
        if (device.isAlipay||device.isApp||device.isWX){
            this.noApp=false;
        };
  },
  methods:{
     onClientReadyIOS(){
        var url = window.location.href;
        var protocol=window.location.protocol;

        var buttons = "[{\"title\":\"二手优品首页\",\"callBack\":\"callIndex\",\"params\":\""+protocol+wapResRoot+"/images/icon-home.png\"}," +
          "{\"title\":\"类目/搜索\",\"callBack\":\"callSearch\",\"params\":\""+protocol+wapResRoot+"/images/icon-search.png\"},"+
          "{\"title\":\"易回收\",\"callBack\":\"callShp\",\"params\":\""+protocol+wapResRoot+"/images/icon-release.png\"},"+
          "{\"title\":\"我的消息\",\"callBack\":\"callRecycle\",\"params\":\""+protocol+wapResRoot+"/images/icon-center.png\"},"+
          "{\"title\":\"我的回收\",\"callBack\":\"mtCenter\",\"params\":\""+protocol+wapResRoot+"/images/icon-center.png\"}]";
        window.SNNativeClient.showRightButtons(buttons);
      },
      onClientReady(){
        var buttons = "[{\"title\":\"二手优品首页\",\"callBack\":\"callIndex\",\"params\":\""+protocol+wapResRoot+"/images/icon-home.png\"}," +
          "{\"title\":\"类目/搜索\",\"callBack\":\"callSearch\",\"params\":\""+protocol+wapResRoot+"/images/icon-search.png\"},"+
          "{\"title\":\"易回收\",\"callBack\":\"callShp\",\"params\":\""+protocol+wapResRoot+"/images/icon-release.png\"},"+
          "{\"title\":\"我的消息\",\"callBack\":\"callRecycle\",\"params\":\""+protocol+wapResRoot+"/images/icon-center.png\"},"+
          "{\"title\":\"我的回收\",\"callBack\":\"mtCenter\",\"params\":\""+protocol+wapResRoot+"/images/icon-center.png\"}]";
        this.showRightButtons(buttons);
      },
      showRightButtons(buttons){
        baseApi.showRightButtons(buttons);
      },
  }
};

</script>
<style lang="scss">
   @import "../../sass/_reset.scss"; 
  @import "./sass/commentContent.scss";
</style>
