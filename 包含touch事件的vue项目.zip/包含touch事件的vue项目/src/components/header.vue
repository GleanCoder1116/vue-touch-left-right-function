<template>
<div class="header" v-if="noApp">
    <!-- 页头部分[[ -->
  <div class="sn-nav sn-block ">
      <div class="sn-nav-back"><a class="sn-iconbtn" href="javascript:void(0)" onclick="history.go(-1);">返回</a></div>
      <div class="sn-nav-title of">
          <h1>优品评价</h1>
      </div>
  </div>
<!-- ]]页头部分 -->
</div>
    
</template>

<script>
export default {
  name: 'header',
  props: ['isApp'],
    data () {
      return{
          noApp:true
        }
    },
   mounted(){
      this.noApp=this.isApp;
      
    },
    methods:{

    },
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style >

</style>
