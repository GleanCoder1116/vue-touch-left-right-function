/*
需要完善的功能;暂时未完善
兼容到PC;
增加webp的图片文件格式;
 */
;(function(window,$){
    'use strict';
    var win = $(window);
    var $win = $(win);
    var pageNum=0;//设定第几页;
    var me;
    var _loadarr;
    var _dataover;//函数节流
    var loaduseArr;//加载用到的数组
    $.fn.dropload = function(options){
        return new MyDropLoad(options);
    };
    var MyDropLoad = function(options){
        var me = this;
        // 是否有数据
        me.isData = true;//如果没有数据的话显示无数据;
        me.init(options);
    };
    // 初始化
    MyDropLoad.prototype.init = function(options){
        var me = this;
        me.opts = $.extend(true, {}, {
            domDown : { // 滑动到底部以后要显示的内容;
                domClass   : 'dropload-down',
                domRefresh : '<div class="dropload-refresh">↑上拉加载更多</div>',
                domLoad    : '<div class="dropload-load"><span class="loading"></span>加载中,请稍等...</div>',
                domNoData  : '<div class="dropload-noData">暂无更多数据</div>'
            },
            datanum :10,//每次加载的条数;
            parentClass:"loadmore-wrap",//加载更多的父元素class名;
            threshold : '0',// 提前加载距离
            dataArr:[],//放置内容数组;
            templay:"",//加载用到的HTML;
            loadDownFn :function(){}// 回调函数
        }, options);
        var str="<div class="+me.opts.domDown.domClass+"></div>";
        $("."+me.opts.parentClass).append(str);//将加载中的样式添加到对应的元素中;
        $("."+me.opts.domDown.domClass).html(me.opts.domDown.domRefresh);
        //滑动加载的函数;
        _loadarr=me.opts.dataArr
        pageNum=0;
        loaduseArr=_loadarr.slice(pageNum,pageNum*1+me.opts.datanum*1);
        pageNum+=me.opts.datanum*1;
        me.opts.loadDownFn(loaduseArr);
        $win.on("scroll",function(){
        clearTimeout(_dataover);
        _dataover = setTimeout(function() {
             // 基本判断方法；获基取整个页面的高度(document.documentElement.offsetHeight或document.body.offsetHeight);页面可视化高度为window.innerHeight 加上页面向上的滚动高度为window.pageYoffset;如果页面的 ;
            var h = document.documentElement.offsetHeight || document.body.offsetHeight, iH = window.innerHeight;
            if (window.pageYOffset + iH+me.opts.threshold*1 >= h) {
                    loaduseArr=_loadarr.slice(pageNum,pageNum*1+me.opts.datanum*1);//截取使用的数组;
                if (loaduseArr.length>0) {
                    _dataover=false;
                    $("."+me.opts.domDown.domClass).html(me.opts.domDown.domRefresh);
                     me.opts.loadDownFn(loaduseArr);
                    pageNum+=me.opts.datanum*1;
                    
                }else{
                      $("."+me.opts.domDown.domClass).html(me.opts.domDown.domNoData);
                }
          }
        }, 100);
    });
}
})(window,window.Zepto || window.jQuery);